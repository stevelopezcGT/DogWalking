﻿namespace DogWalking.Common
{
    public static class AppSession
    {
        public static string CurrentUsername { get; set; }
    }
}